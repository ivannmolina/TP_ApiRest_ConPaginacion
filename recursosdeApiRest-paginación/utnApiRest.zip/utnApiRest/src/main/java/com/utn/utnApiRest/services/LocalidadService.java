package com.utn.utnApiRest.services;

import com.utn.utnApiRest.entities.Localidad;

public interface LocalidadService extends BaseService<Localidad, Long>{

}